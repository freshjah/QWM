from fastapi import FastAPI, Body
from fastapi.responses import JSONResponse

app = FastAPI()

@app.post("/sign")
async def sign(data: str = Body(...)):
    # Dummy sign
    return JSONResponse({"signature": "dummy_signature"})

@app.post("/verify")
async def verify(data: str = Body(...), signature: str = Body(...)):
    # Dummy verification
    return JSONResponse({"valid": True, "reason": "Matched"})
