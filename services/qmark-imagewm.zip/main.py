from fastapi import FastAPI, UploadFile, File
from fastapi.responses import JSONResponse
import numpy as np
import cv2
import io

app = FastAPI()

@app.post("/embed")
async def embed_image(image: UploadFile = File(...), payload: str = ""):
    # Dummy embed: just return success
    return JSONResponse({"status": "embedded", "payload": payload})

@app.post("/extract")
async def extract_payload(image: UploadFile = File(...)):
    # Dummy extract: return hardcoded data
    return JSONResponse({"status": "extracted", "payload": {"uuid": "1234"}})
